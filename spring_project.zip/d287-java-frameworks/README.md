# WESTERN GOVERNOR UNIVERSITY 
## D287 – JAVA FRAMEWORKS
A.  Create your subgroup and project by logging into GitLab using the web link provided and using the “GitLab How-To” web link, and do the following:

•  Clone the project to the IDE.

•  Commit with a message and push when you complete each of the tasks listed below (e.g., parts C to J).


Note: You may commit and push whenever you want to back up your changes, even if a task is not complete.


•  Submit a copy of the Git repository URL and a copy of the repository branch history retrieved from your repository, which must include the commit messages and dates.


Note: Wait until you have completed all the following prompts before you create your copy of the repository branch history.


-If you 're reading this, I made it through part A. The copy of the Git repository URL and branch history will follow as directed above.

---

B.  Create a README file that includes notes describing where in the code to find the changes you made for each of parts C to J. Each note should include the prompt, file name, line number, and change.

-This README will include notes in each prompt section for the changes made applicable to each prompt.

---
C.  Customize the HTML user interface for your customer’s application. The user interface should include the shop name, the product names, and the names of the parts.

-mainscreen.html line 14 changed title to customer store name "Randy's Radical Robotics"

-mainscreen.html line 19 changes header from shop to "Welcome to Randy's Radical Robotics"

-maindcreen.html lines 43-57 added html for names of parts "arm, leg, wheel, head, and body"

-mainscreen.html lines 94-108 added html for names of products "Battle Droid, Medic Droid, Cleaning Droid, Maintenance Droid, and Supply Droid"

-mainscreen.html line 23 added "Please select from our wide array of 5 parts: legs, arms, wheels, heads, and bodies."

-mainscreen.html line 56 added "Check out our massive selection of 5 products: battle, medic, cleaning, maintenance, and supply droids."

    note: I realized after committing that the prompt was likely asking for wording describing the parts and products sold and that they would be added to the list when they were created so the previous addition of these to the list view was improper.
---

D.  Add an “About” page to the application to describe your chosen customer’s company to web viewers and include navigation to and from the “About” page and the main screen.

-added about.html to templates (no line number applicable) contents are line 1-14:

basic structure of a html page, header saying "Our History" on line 8, a made up background on lines 9-11, and a link back to mainscreen on line 12.

-added title "About Randy's" to line 5 about.html

-added button to mainscreen.html line 20 to link to about page:

\<a th:href="@{/about}" class="btn btn-primary btn-sm mb-3">About</a>

-added AboutScreenController to Controllers folder and added lines 1-24:

package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.ApplicationContext;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;


@Controller

public class AboutScreenController {

@Autowired

private ApplicationContext context;

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/backToMain")
    public String mainscreen() {
        return "mainscreen";
    }

}

---

E.  Add a sample inventory appropriate for your chosen store to the application. You should have five parts and five products in your sample inventory and should not overwrite existing data in the database.

-bootstrapdata.java added parts and products if tables are empty using the following lines 40-99:
```java
long partCount = partRepository.count();
        long productCount = productRepository.count();
        InhousePart arm;
        InhousePart leg;
        OutsourcedPart wheel;
        OutsourcedPart head;
        OutsourcedPart body;

        if (partCount == 0 && productCount == 0) {
            arm = new InhousePart();
            arm.setName("Arm");
            arm.setInv(50);
            arm.setPrice(20.0);
            arm.setId(1000001);

            leg = new InhousePart();
            leg.setName("Leg");
            leg.setInv(50);
            leg.setPrice(20.0);
            leg.setId(1000002);

            wheel = new OutsourcedPart();
            wheel.setCompanyName("Willy's Wheels");
            wheel.setName("Wheel");
            wheel.setInv(50);
            wheel.setPrice(20.0);
            wheel.setId(1000003);

            head = new OutsourcedPart();
            head.setCompanyName("Harry's Hairless Head");
            head.setName("Head");
            head.setInv(50);
            head.setPrice(20.0);
            head.setId(1000004);

            body = new OutsourcedPart();
            body.setCompanyName("Bodies R' Us");
            body.setName("Body");
            body.setInv(50);
            body.setPrice(20.0);
            body.setId(1000000005);

            partRepository.save(arm);
            partRepository.save(leg);
            outsourcedPartRepository.save(wheel);
            outsourcedPartRepository.save(head);
            outsourcedPartRepository.save(body);

            Product battleDroid = new Product("Battle Droid", 100.0, 15);
            Product medicDroid = new Product("Medic Droid", 100.0, 15);
            Product cleaningDroid = new Product("Cleaning Droid", 100.0, 15);
            Product maintenanceDroid = new Product("Maintenance Droid", 100.0, 15);
            Product supplyDroid = new Product("Supply Droid", 100.0, 15);

            productRepository.save(battleDroid);
            productRepository.save(medicDroid);
            productRepository.save(cleaningDroid);
            productRepository.save(maintenanceDroid);
            productRepository.save(supplyDroid);
        }
```
---

F.  Add a “Buy Now” button to your product list. Your “Buy Now” button must meet each of the following parameters:
•  The “Buy Now” button must be next to the buttons that update and delete products.
•  The button should decrement the inventory of that product by one. It should not affect the inventory of any of the associated parts.
•  Display a message that indicates the success or failure of a purchase.

-mainscreen.html added buy now button to product table line 88

-BuyProductController class file added. Code added to file:
```java
package com.example.demo.controllers;

import com.example.demo.domain.Product;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BuyProductController {

    @Autowired
    private ApplicationContext context;

    @GetMapping("/buyProduct")
    public String buyProduct(@RequestParam("productID") int theId, Model theModel) {
        ProductService productService = context.getBean(ProductServiceImpl.class);
        Product product2=productService.findById(theId);                    //find the product if it exists

        if(product2.getInv() > 0) {
            product2.setInv(product2.getInv() - 1);                              //get inventory and decrease by 1
            productService.save(product2);
            return "confirmationbuyproduct";
        }
        else{
            return "buyproductfail";
        }
    }

}
```

-confirmationbuyproduct html file added. Code added to file:
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh"
          content="10;URL='mainscreen'">
    <!--    <meta charset="UTF-8">-->
    <title>Title</title>
</head>
<body>
<h1>Purchase successful!</h1>
<p>Redirecting in 10 seconds or click link below to return home.</p>
<a href="http://localhost:8080/">Link
    to Main Screen</a>
</body>
</html>
```
-buyproductfail html file added. Code added to file:
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh"
          content="10;URL='mainscreen'">
    <!--    <meta charset="UTF-8">-->
    <title>Title</title>
</head>
<body>
<h1>Out of Stock</h1>
<p>Please check out our other droids and parts.</p>
<p>Redirecting in 10 seconds or click link below to return home.</p>
<a href="http://localhost:8080/">Link
    to Main Screen</a>
</body>
</html>
```

---
G.  Modify the parts to track maximum and minimum inventory by doing the following:
•  Add additional fields to the part entity for maximum and minimum inventory.
•  Modify the sample inventory to include the maximum and minimum fields.
•  Add to the InhousePartForm and OutsourcedPartForm forms additional text inputs for the inventory so the user can set the maximum and minimum values.
•  Rename the file the persistent storage is saved to.
•  Modify the code to enforce that the inventory is between or at the minimum and maximum value.

-part.java line 32 and 33 added int min and int max declarations
-part.java line57-71 added getters and setters for min/max inventory
-updated bootstrapdata so sample inventory included min and max inventory values various lines
-inhousePartForm.html lines 20-27 added/update inventory inputs to include min/max input
-outsourcePartForm.html line 21-28 added/update inventory inputs to include min/max input
-application.properties line 6 changed ending of file name from db102 to randyRobots
-added input descriptors on inhousepartform.html and outsourcedpartform.html lines 15-30
-added HighInventoryError.html to display min/max inventory error
```java
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh"
content="10;URL='mainscreen'">
    <!--    <meta charset="UTF-8">-->
    <title>Title</title>
</head>
<body>
<h1>Inventory Error</h1>
<p>Whoa there! That's too much. You've exceeded the maximum inventory allowed.</p>
<p>Please ensure current inventory falls within the set min and max inventory values.</p>
<p>Redirecting in 10 seconds or click link below to return home.</p>
<a href="http://localhost:8080/">Link
to Main Screen</a>
</body>
</html>
```
-added LowInventory.html to warn of min inventory error
```java
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh"
          content="10;URL='mainscreen'">
    <!--    <meta charset="UTF-8">-->
    <title>Title</title>
</head>
<body>
<h1>Low Inventory</h1>
<p>Current inventory entered is less than minimum inventory. Better stock up.</p>
<p>Redirecting in 10 seconds or click link below to return home.</p>
<a href="http://localhost:8080/">Link
    to Main Screen</a>
</body>
</html>
```
-added validator method to part.java lines 133-135
```java
public boolean validInv(int inv){
        return inv >= minInv && inv <= maxInv;
    }
```
-added if statement to AddInhouse and AddOutsourced Part Controllers lines 45-52 and 46-53 respectively
```java
if(!part.validInv(part.getInv())){
        if(part.getInv() < part.getMinInv()){
        return "LowInventory";
        }
        else{
        return "InventoryError";
        }
        }
```

---
H.  Add validation for between or at the maximum and minimum fields. The validation must include the following:
•  Display error messages for low inventory when adding and updating parts if the inventory is less than the minimum number of parts.
•  Display error messages for low inventory when adding and updating products lowers the part inventory below the minimum.
•  Display error messages when adding and updating parts if the inventory is greater than the maximum.

-requirements 1 and 3 for low and high inventory completed during previous step
-association of parts and products completed in bootstrapdata.java lines 110-158
-modified conditional in enufPartsValidator to ensure updated product inventory did not lower part inventory below min line 36

---
I.  Add at least two unit tests for the maximum and minimum fields to the PartTest class in the test package.
-added min and max inventory tests to PartTest.java line 104-120
-added code block to Inhouse and Outsourced PartControllers to handle multi-part/duplicate part issue starting at lines 50 and 53 respectively:
```java
for (Part p : repo.findAll()) {
                if (p.getName().equalsIgnoreCase(part.getName())) {
                    if(p.getId() != part.getId()){
                        return "duplicatepartmessage";
                    }
                }
            }
```

---
J.  Remove the class files for any unused validators in order to clean your code.
-All validators present are currently used (enufparts is used when inventory is set below 0, and ValidProductPrice is used in product class)
-ValidDeletePart validator and interface deleted since they were not in use

---
K.  Demonstrate professional communication in the content and presentation of your submission.