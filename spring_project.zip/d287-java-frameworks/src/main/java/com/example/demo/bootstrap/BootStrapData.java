package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.*;

import static java.lang.System.out;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;
    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        long partCount = partRepository.count();
        long productCount = productRepository.count();
        InhousePart arm;
        InhousePart leg;
        OutsourcedPart wheel;
        OutsourcedPart head;
        OutsourcedPart body;

        if (partCount == 0 && productCount == 0) {
            arm = new InhousePart();
            arm.setName("Arm");
            arm.setInv(50);
            arm.setPrice(20.0);
            arm.setPartId(1000001);
            arm.setMinInv(5);
            arm.setMaxInv(50);

            leg = new InhousePart();
            leg.setName("Leg");
            leg.setInv(50);
            leg.setPrice(20.0);
            leg.setPartId(1000002);
            leg.setMinInv(5);
            leg.setMaxInv(50);

            wheel = new OutsourcedPart();
            wheel.setCompanyName("Willy's Wheels");
            wheel.setName("Wheel");
            wheel.setInv(50);
            wheel.setPrice(20.0);
            wheel.setMinInv(5);
            wheel.setMaxInv(50);

            head = new OutsourcedPart();
            head.setCompanyName("Harry's Hairless Head");
            head.setName("Head");
            head.setInv(50);
            head.setPrice(20.0);
            head.setMinInv(5);
            head.setMaxInv(50);

            body = new OutsourcedPart();
            body.setCompanyName("Bodies R' Us");
            body.setName("Body");
            body.setInv(50);
            body.setPrice(20.0);
            body.setMinInv(5);
            body.setMaxInv(50);

            partRepository.save(arm);
            partRepository.save(leg);
            outsourcedPartRepository.save(wheel);
            outsourcedPartRepository.save(head);
            outsourcedPartRepository.save(body);

            Product battleDroid = new Product("Battle Droid", 100.0, 15);
            Product medicDroid = new Product("Medic Droid", 100.0, 15);
            Product cleaningDroid = new Product("Cleaning Droid", 100.0, 15);
            Product maintenanceDroid = new Product("Maintenance Droid", 100.0, 15);
            Product supplyDroid = new Product("Supply Droid", 100.0, 15);

            productRepository.save(battleDroid);
            productRepository.save(medicDroid);
            productRepository.save(cleaningDroid);
            productRepository.save(maintenanceDroid);
            productRepository.save(supplyDroid);

            Set<Part> humanoidParts = new HashSet<>();
            humanoidParts.add(arm);
            humanoidParts.add(leg);
            humanoidParts.add(body);
            humanoidParts.add(head);

            Set<Part> botParts = new HashSet<>();
            botParts.add(body);
            botParts.add(wheel);

            battleDroid.setParts(humanoidParts);
            medicDroid.setParts(humanoidParts);
            cleaningDroid.setParts(botParts);
            supplyDroid.setParts(humanoidParts);
            maintenanceDroid.setParts(humanoidParts);

            productRepository.save(battleDroid);
            productRepository.save(medicDroid);
            productRepository.save(cleaningDroid);
            productRepository.save(maintenanceDroid);
            productRepository.save(supplyDroid);

            Set<Product> allProducts = new HashSet<>();
            allProducts.add(battleDroid);
            allProducts.add(medicDroid);
            allProducts.add(cleaningDroid);
            allProducts.add(maintenanceDroid);
            allProducts.add(supplyDroid);

            Set<Product> humanoidProducts = new HashSet<>();
            humanoidProducts.add(battleDroid);
            humanoidProducts.add(medicDroid);
            humanoidProducts.add(maintenanceDroid);
            humanoidProducts.add(supplyDroid);

            Set<Product> botProducts = new HashSet<>();
            botProducts.add(cleaningDroid);

            arm.setProducts(humanoidProducts);
            leg.setProducts(humanoidProducts);
            wheel.setProducts(botProducts);
            head.setProducts(humanoidProducts);
            body.setProducts(allProducts);

            partRepository.save(arm);
            partRepository.save(leg);
            outsourcedPartRepository.save(wheel);
            outsourcedPartRepository.save(head);
            outsourcedPartRepository.save(body);
        }

        List<OutsourcedPart> outsourcedParts = (List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for (OutsourcedPart part : outsourcedParts) {
            out.println(part.getName() + " " + part.getCompanyName());
        }



        out.println("Started in Bootstrap");
        out.println("Number of Products "+productRepository.count());
        out.println(productRepository.findAll());
        out.println("Number of Parts "+partRepository.count());
        out.println(partRepository.findAll());

    }
}
